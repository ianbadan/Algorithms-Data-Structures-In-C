#include<stdio.h>
#include<stdlib.h>

#define qtd 10

int dados[qtd];
int inicio;
int fim;


void inicializaFilaC(){
    inicio=0;
    fim=0;
}

int filaCheia(){
    if((fim+1)%qtd==inicio){
        printf("Fila Cheia\n");
        return 1;
    }
    return 0;
}

int filaVazia(){
    if(fim==inicio){
        printf("Fila Vazia\n");
        return 1;
    }
    return 0;
}

int enqueue (int valor){
    if(filaCheia()){
        return -1;
    }
    dados[fim]=valor;
    fim=(fim+1)%qtd;
    return fim;
}

int dequeue(){
    if(filaVazia()){
        return -1;
    }
    int aux=dados[inicio];
    inicio=(inicio+1)%qtd;
    return aux;
}

int tamanhoFila(){
    if(fim >= inicio) return fim - inicio;
    return (fim+qtd) - inicio;
}
void main(){
    int i, valor;
;
    inicializaFilaC();
    printf("%d\n", tamanhoFila());
    for(i=0;i<qtd-1;i++){
        valor=rand()%100;
        printf("Fim: %d\n", enqueue(valor));
    }
    printf("%d\n", tamanhoFila());
    for(i=0;i<3;i++){
        printf("Valor retirado: %d\n", dequeue());
    }
    for(i=0;i<1;i++){
        valor=rand()%100;
        printf("Fim: %d\n", enqueue(valor));
    }
    printf("%d\n", tamanhoFila());
}


